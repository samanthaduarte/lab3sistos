#include <stdio.h>
#include <unistd.h>

int main(){
	pid_t p1;
	p1 = fork();
	if(p1 == -1){
		printf("Error en fork\n");
		return(-1);
	}else if(!p1){
		int i;
		for(i=1;i<=4000000;i++){
			printf("%d\n", i);
		}
	}else{
		printf("Proceso padre: PID %d\n", (int)getpid());
		while(1>0){};
	}
	
	return(0);
}
