#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
	pid_t p1;
	pid_t p2;
	pid_t p3;
	clock_t c1;
	clock_t c2;

	c1=clock();
	
	p1 = fork();
	if(p1 == -1){
		printf("Error en fork");
		return (-1);
	}else if(!p1){
		printf("Proceso hijo: PID %d\n", getpid());
		wait(NULL);
		p2=fork();
		if(!p2){
			printf("Proceso nieto: PID %d\n", getpid());
			wait(NULL);
			p3=fork();
			if(!p3){
				printf("Proceso biznieto: PID %d\n", getpid());
				int i;
				for(i=0;i<1000000;i++){
				}
			
			}else{
				printf("Proceso nieto: PID %d\n", getpid());
			}
		}else{
			printf("Proceso hijo: PID %d\n", getpid());
		}		
	}else{
		printf("Proceso padre: PID %d\n", getpid());
		wait(NULL);
		c2=clock();
		double res;
		res = (double)c2-c1;
		printf("%f",res);
	}
	return(0);
}
