#include <stdio.h>
#include <time.h>

int main(){
	clock_t c1;
	clock_t c2;

	c1 = clock();
	int i;
	for(i=0;i<1000000;i++){
	}
	int j;
	for(j=0;j<1000000;j++){
	}
	int k;
	for(k=0;k<1000000;k++){
	}
	c2 = clock();
	double res;
	res = (double)c2-c1;
	printf("%f",res);
	return(0);
}
